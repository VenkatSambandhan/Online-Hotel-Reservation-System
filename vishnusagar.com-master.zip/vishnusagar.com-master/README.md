# vishnusagar.com
======================================================================

	  Website Name: Vishnu Sagar Restaurant and Lodge
	  Author: Vishwas Vijaya Kumar, Venkat Sambandhan, Maaz Syed

======================================================================

+++ License +++
Restaurant website is 100% FREE! Thank you so much! :)

   

+++ EDITING +++

The code may be edited with any HTML editor. If you do not know where to get one, you may consider trying NotePad++. It can be downloaded at notepad-plus.sourceforge.net and it's free.


   +++ HOW TO PUT YOUR OWN LOGO+++

You need to replace logo.png (it is located in site>images>logo.png) with your own .png file. 


+++ IMPORTANT NOTICE +++

We don't provide support services on this website.
This website is produced according to the latest web standards and we've been trying to make the process of working with them as easy as possible, so for people with minimum web develpment experience, it should be easy to work with them. 

   
