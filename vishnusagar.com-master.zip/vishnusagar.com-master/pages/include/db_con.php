<?php
// $con=mysql_connect("localhost","root","");
// mysql_select_db("assignment",$con) or die(mysql_error($con));



// session_start();
// $_SESSION['con'] = pg_connect("host=ec2-54-83-59-110.compute-1.amazonaws.com port=5432 dbname=d8h402rrjiluoa user=gxmemxqrkaujqo password=ph3wu2QeU344cQsRFFi5QGtqF-");$con = pg_connect("host=ec2-54-83-59-110.compute-1.amazonaws.com port=5432 dbname=d8h402rrjiluoa user=gxmemxqrkaujqo password=ph3wu2QeU344cQsRFFi5QGtqF-");
//mysql_select_db("assignment",$con) or die("Couldn't connect to the database"); //MS
// error_reporting(E_ALL ^ E_NOTICE);
?>